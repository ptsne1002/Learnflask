from app import db
from app.models import User, Post


users = User.query.filter_by(id="1").first()

print(users.username)