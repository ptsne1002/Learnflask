from app import app
from app.formSignIn import LoginForm
from flask import render_template

@app.route('/')
@app.route('/home')
def home():
    form = LoginForm()
    return render_template('signin.html',title = 'Sign In', page='Home',form=form)

