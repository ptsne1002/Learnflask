from app import app
from app.formSignIn import load_username_by_id
from flask import render_template, request, redirect, url_for, jsonify
from app.models import User, Post


@app.route('/hello')
def haha():
    return render_template('index.html',title = 'Hello', page='')


def hehe():
    return '''<h1> Hehe hello PTS </h1> <a href="/home">go to About!</a>'''


@app.route('/about', methods=['GET', 'POST'])
def about():
    form = load_username_by_id()
    return render_template('about.html',title = 'About', page='About', form=form)

@app.route('/get_username', methods=['POST', 'GET'])
def get_username():
    if request.method == 'POST':
        data_client = request.get_json()
        id_user = data_client['id_user']
        users = User.query.filter_by(id=id_user).first()
    results = {'username': users.username}
    return jsonify(results)